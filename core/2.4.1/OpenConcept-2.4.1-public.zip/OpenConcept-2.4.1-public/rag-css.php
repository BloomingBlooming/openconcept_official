<?php

declare(strict_types=1);

require __DIR__ . '/public/rag-css.php';
